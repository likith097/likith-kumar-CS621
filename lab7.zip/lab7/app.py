from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, UserProfile
import re

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_unique_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'signin'

@login_manager.user_loader
def load_user(user_id):
    return UserProfile.query.get(int(user_id))

def validate_password(password):
    return (len(password) >= 8 and
            re.search(r"[a-z]", password) and
            re.search(r"[A-Z]", password) and
            password[-1].isdigit())

@app.route('/')
def home():
    return redirect(url_for('signin'))

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = UserProfile.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('secret_page'))
        flash('Invalid email or password')
    return render_template('signin.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if UserProfile.query.filter_by(email=email).first():
            flash('Email already registered')
        elif password != confirm_password:
            flash('Passwords do not match')
        elif not validate_password(password):
            flash('Password must be at least 8 characters long, contain a lowercase letter, an uppercase letter, and end with a number')
        else:
            hashed_password = generate_password_hash(password)
            new_user = UserProfile(first_name=first_name, last_name=last_name, email=email, password_hash=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('thankyou'))
    return render_template('signup.html')

@app.route('/secret_page')
@login_required
def secret_page():
    return render_template('secretpage.html')

@app.route('/thankyou')
def thankyou():
    return render_template('thankyou.html')

@app.route('/signout')
@login_required
def signout():
    logout_user()
    return redirect(url_for('signin'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)